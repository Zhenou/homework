<template>
  <div>货主管理</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
