<template>
  <div>承运商管理</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
