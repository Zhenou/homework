<template>
  <div>盘点号</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
