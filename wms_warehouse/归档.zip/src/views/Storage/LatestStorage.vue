<template>
  <div>实时库存</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
