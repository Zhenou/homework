<template>
  <div>库存损益</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
