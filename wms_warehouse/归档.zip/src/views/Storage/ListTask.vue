<template>
  <div>盘点任务</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
