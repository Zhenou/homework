<template>
  <div>检获任务</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
