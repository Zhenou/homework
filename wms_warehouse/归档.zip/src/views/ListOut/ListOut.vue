<template>
  <div>出库单</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
