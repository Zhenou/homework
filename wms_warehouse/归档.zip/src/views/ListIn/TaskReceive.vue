<template>
  <div>收货任务</div>
</template>

<script>
export default {

}
</script>

<style>

</style>
