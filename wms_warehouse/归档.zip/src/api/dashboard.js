import request from '@/utils/request'

export const todo = () => request.get('ips/home/todo')
