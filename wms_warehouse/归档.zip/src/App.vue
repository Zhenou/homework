<template>
  <div id="app">
    <router-view></router-view>
  </div>
</template>

<style lang="less">
body{
  margin: 0px;
  padding: 0px;

}
</style>
