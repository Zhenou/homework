export default {
  // 状态
  status: [{
    id: '1',
    value: '启用'
  },
  {
    id: '2',
    value: '禁用'
  }
  ],
  role: [{
    id: '1',
    value: '管理员'
  },
  {
    id: '2',
    value: '审核员'
  },
  {
    id: '3',
    value: '普通用户'
  },
  {
    id: '4',
    value: '试题录入'
  }
  ]
}
