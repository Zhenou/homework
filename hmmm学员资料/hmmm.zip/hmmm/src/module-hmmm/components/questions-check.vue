<template>
  <div class='container'>试题审核对话框</div>
</template>

<script>
export default {}
</script>

<style scoped lang='less'></style>
