<template>
  <div class='container'>目录管理</div>
</template>

<script>
export default {}
</script>

<style scoped lang='less'></style>
