<template>
  <div class='container'>精选题库</div>
</template>

<script>
export default {}
</script>

<style scoped lang='less'></style>
