<template>
  <div class='container'>面试技巧</div>
</template>

<script>
export default {}
</script>

<style scoped lang='less'>

</style>
