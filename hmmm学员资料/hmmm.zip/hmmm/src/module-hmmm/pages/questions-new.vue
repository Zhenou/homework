<template>
  <div class='container'>试题录入</div>
</template>

<script>
export default {}
</script>

<style scoped lang='less'></style>
