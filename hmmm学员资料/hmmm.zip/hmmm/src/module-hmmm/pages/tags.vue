<template>
  <div class='container'>标签管理</div>
</template>

<script>
export default {}
</script>

<style scoped lang='less'></style>
